#include "WFG7.h"

extern "C" {
	Individual *maker(){
		return new WFG7();
	}
}
