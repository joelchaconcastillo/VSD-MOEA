#include "WFG8.h"

extern "C" {
	Individual *maker(){
		return new WFG8();
	}
}
