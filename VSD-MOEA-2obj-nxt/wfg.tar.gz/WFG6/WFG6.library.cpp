#include "WFG6.h"

extern "C" {
	Individual *maker(){
		return new WFG6();
	}
}
